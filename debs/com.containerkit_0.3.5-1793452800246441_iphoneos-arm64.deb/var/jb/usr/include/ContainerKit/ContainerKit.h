#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Public ContainerKit SDK for other tweaks. Link or dlopen
/// libContainerKitCore.dylib and use CKContainerKit.sharedInstance.
///
/// The SDK reads and writes the Manager's container store, so it works only
/// in processes that can reach that store (SpringBoard and other unsandboxed
/// jailbreak processes). In a sandboxed app every call reports unavailable.
///
/// Destructive operations (wipe, delete, set as system default, backup and
/// restore) are not exposed: they stay in the Manager app, where the user
/// confirms them. Launching a container goes through the Manager launch URL,
/// so authentication rules and the chooser still apply.
FOUNDATION_EXPORT NSErrorDomain const CKContainerKitErrorDomain;
/// Selection value meaning the app's original (default) data.
FOUNDATION_EXPORT NSString * const CKContainerKitOriginalSelection;
/// Posted (Darwin notify, no payload) after any container or selection change.
FOUNDATION_EXPORT NSString * const CKContainerKitChangedNotificationName;

typedef NS_ERROR_ENUM(CKContainerKitErrorDomain, CKContainerKitErrorCode) {
    CKContainerKitErrorUnavailable = 1,
    CKContainerKitErrorInvalidArgument = 2,
    CKContainerKitErrorNotFound = 3,
};

@protocol CKContainerKitObserver <NSObject>
@optional
/// Called on the main queue after any change; re-read the state you need.
- (void)containerKitDidChange;
@end

@interface CKContainerKit : NSObject
@property(class, nonatomic, readonly) CKContainerKit *sharedInstance;
/// NO when the Manager store cannot be reached from this process.
@property(nonatomic, readonly, getter=isAvailable) BOOL available;

/// Applications that have at least one ContainerKit container.
- (nullable NSArray<NSString *> *)applicationIdentifiersWithContainersWithError:(NSError * _Nullable * _Nullable)error;
/// Each entry: identifier (public lowercase UUID), storageIdentifier (stable UUID), name;
/// vendorIdentifier is present when explicitly configured.
- (nullable NSArray<NSDictionary<NSString *, NSString *> *> *)containersForApplication:(NSString *)bundleIdentifier
                                                                                 error:(NSError * _Nullable * _Nullable)error;
/// Saved launch choice: a container UUID or CKContainerKitOriginalSelection.
- (nullable NSString *)preferredSelectionForApplication:(NSString *)bundleIdentifier error:(NSError * _Nullable * _Nullable)error;
/// Saves the launch choice only. Authentication rules still apply at launch.
- (BOOL)setPreferredSelection:(NSString *)selection forApplication:(NSString *)bundleIdentifier
                        error:(NSError * _Nullable * _Nullable)error;
/// Creates an empty container; returns its UUID.
- (nullable NSString *)createContainerNamed:(NSString *)name forApplication:(NSString *)bundleIdentifier
                                      error:(NSError * _Nullable * _Nullable)error;
- (BOOL)renameContainer:(NSString *)containerIdentifier to:(NSString *)name forApplication:(NSString *)bundleIdentifier
                  error:(NSError * _Nullable * _Nullable)error;
/// Changes the public identifier; the stable data/keychain ownership is preserved.
- (BOOL)setIdentifier:(NSString *)identifier forContainer:(NSString *)containerIdentifier
      forApplication:(NSString *)bundleIdentifier error:(NSError * _Nullable * _Nullable)error;
/// {} follows system; saved overrides apply at the next cold launch.
- (BOOL)setLocaleProfile:(NSDictionary *)profile forContainer:(NSString *)containerIdentifier
          forApplication:(NSString *)bundleIdentifier error:(NSError * _Nullable * _Nullable)error;
/// nil follows the public container identifier. Existing processes keep their IDFV until cold launch.
/// Saves advertising policy for the next cold launch; native ATT restrictions still apply.
- (BOOL)setAdvertisingIdentifierMode:(NSString *)mode identifier:(nullable NSString *)identifier
    forContainer:(NSString *)containerIdentifier forApplication:(NSString *)bundleIdentifier error:(NSError **)error;
- (BOOL)setVendorIdentifier:(nullable NSString *)identifier forContainer:(NSString *)containerIdentifier
            forApplication:(NSString *)bundleIdentifier error:(NSError * _Nullable * _Nullable)error;
/// Requires a device-supported native Accounts backend; unsupported isolation fails at launch.
- (BOOL)setSystemAccountsIsolated:(BOOL)isolated forContainer:(NSString *)containerIdentifier
                  forApplication:(NSString *)bundleIdentifier error:(NSError * _Nullable * _Nullable)error;
/// URL that opens the Manager launch flow; nil selection shows the chooser.
- (nullable NSURL *)launchURLForApplication:(NSString *)bundleIdentifier selection:(nullable NSString *)selection;

/// Opens visible wipe confirmation and authentication. No wipe is performed by this SDK.
- (nullable NSURL *)wipeURLForApplication:(NSString *)bundleIdentifier container:(NSString *)containerIdentifier repopulate:(BOOL)repopulate;

/// URL that opens the Manager backup flow for a container: the Manager performs the
/// authenticated capture. Returns nil when the application or container is unknown.
- (nullable NSURL *)backupURLForApplication:(NSString *)bundleIdentifier
                                  container:(NSString *)containerIdentifier;
/// URL that opens the Manager restore flow for a container.
- (nullable NSURL *)restoreURLForApplication:(NSString *)bundleIdentifier
                                   container:(NSString *)containerIdentifier;
/// Persisted Push counts: bundle -> aggregate, capped at the desktop ceiling.
/// Reads existing state under the Core lease and nonblocking Push shared lock;
/// only registered immutable selections with enabled/allowed policy and recorded
/// non-revoked registrations participate. Works in same-owner processes that can
/// read the Store, including unsandboxed processes outside SpringBoard.
/// nil/error means missing/unsafe/busy/incomplete state; a proven empty or never
/// initialized Push store yields @{}. Missing apps are absent, not invented zeros.
/// These cached counts do not prove current epoch, runtime readiness, the live
/// SpringBoard icon, precise app unread state, or APNs delivery. No Broker waits.
- (nullable NSDictionary<NSString *, NSNumber *> *)aggregateBadgeCountsWithError:(NSError * _Nullable * _Nullable)error;

- (void)addObserver:(id<CKContainerKitObserver>)observer;
- (void)removeObserver:(id<CKContainerKitObserver>)observer;
- (instancetype)init NS_UNAVAILABLE;
@end

/// Store location shared by Manager, SpringBoard and the SDK; nil when this
/// process cannot resolve it.
FOUNDATION_EXPORT NSURL * _Nullable CKContainerKitSharedStoreURL(void);
#if defined(CK_CONTAINERKIT_SDK_TESTING)
FOUNDATION_EXPORT void CKContainerKitSetStoreURLForTesting(NSURL * _Nullable url);
#endif

NS_ASSUME_NONNULL_END
